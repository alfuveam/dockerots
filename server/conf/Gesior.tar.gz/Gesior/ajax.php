<?php
$_GET['subtopic'] = 'ajax';
$_REQUEST['subtopic'] = 'ajax';
include('index.php');