<?php
define('ONLY_PAGE', true);
$_GET['subtopic'] = 'ajax_character';
$_REQUEST['subtopic'] = 'ajax_character';
include('index.php');