# Global Full Free Version!

# Teste Server Online:
-> Site [Clique aqui!](http://35.199.127.221)

# Forums:
-> [Fórum OTBR](http://www.otserv.com.br)

-> [Fórum XTibia](http://www.xtibia.com)

-> [Fórum TibiaKing](http://www.tibiaking.com)

-> [Fórum Otland](http://www.otland.net)

# Tutoriais
-> Como compilar o servidor  [TFS Wiki](https://github.com/mattyx14/otxserver/wiki)

# Ferramentas para download
-> SDK disponivel com as ferramentas o servidor [Download aqui!](https://github.com/mattyx14/otxserver/wiki/Compilling-on-Windows)

-> Cliente disponivel Frequentemente atualizado e compativel (10/11) [Download aqui!](https://github.com/Qwizer/tools)

-> Item Editor e Object Build [Download aqui!](https://github.com/Qwizer/tools)

-> Remeres Map Editor [Download aqui!](https://github.com/Qwizer/tools/blob/master/RME.zip)

-> Website Compativel (Riicksouza) [Gesior Compativel](https://github.com/Riicksouzaa/TheRealGesiorFerobra/archive/master.zip).

# Contato:
-> Skype: onjogos

-> [Whatsapp](http://api.whatsapp.com/send?1=pt_BR&phone=5566984274493) ou 66 9 8427-4493

-> Discord: Qwizer#5713
