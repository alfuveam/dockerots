ZE = -- Zumbi Event
{
	tpOpen = {x=32358, y=32213, z=7}, -- posi��o de onde abrir� o teleport para entrar no evento.
	tpTimeOpen = 1, -- tempo que o tp ficar� aberto (em minutes).
	posEnterEvent = {x = 32383, y = 31891, z = 7}, -- posi��o de onde os players ir�o para dentro do evento.
	reward = {2160, 10, "You won 100k."}, -- recompensa: "itemid, quantidade, msg"
	storage = 88789,
}