function onRaid()
	local monster = Game.createMonster("Gaz'Haragoth", Position(33538, 32381, 12))
	 monster:setReward(true)
end
