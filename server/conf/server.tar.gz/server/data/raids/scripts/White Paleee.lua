function onRaid()
 local monster = Game.createMonster("White Pale", Position(32224, 32761, 10))
 monster:setReward(true)
end
