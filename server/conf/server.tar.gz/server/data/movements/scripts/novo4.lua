function onStepIn(cid, item, position, fromPosition)
	doPlayerSendTextMessage(cid, MESSAGE_INFO_DESCR, "You need 4 players to do this quest.")
	return true
end
